#include <float.h>
#include <math.h>

/* Linear RGB, row-major. Error is carried in the mutable input array. */
void diffuse(float *image, int width, int height, const float *palette,
             int color_count, int dither, unsigned char *indices)
{
    for (int y = 0; y < height; ++y) {
        const int direction = y % 2 == 0 ? 1 : -1;
        for (int column = 0; column < width; ++column) {
            const int x = direction == 1 ? column : width - 1 - column;
            const int index = y * width + x;
            float *pixel = image + 3 * index;
            int choice = 0;
            float best = FLT_MAX;
            for (int k = 0; k < color_count; ++k) {
                const float *candidate = palette + 3 * k;
                float r = pixel[0] - candidate[0];
                float g = pixel[1] - candidate[1];
                float b = pixel[2] - candidate[2];
                float distance = .26*r*r + .50*g*g + .24*b*b;
                if (distance < best) {
                    best = distance;
                    choice = k;
                }
            }
            indices[index] = (unsigned char)choice;
            if (!dither) continue;

            const int forward = x + direction;
            const int back = x - direction;
            for (int channel = 0; channel < 3; ++channel) {
                float error = pixel[channel] - palette[3 * choice + channel];
                float share = fmaxf(-1, fminf(1, error)) / 16;
                if (forward >= 0 && forward < width)
                    image[3*(index+direction)+channel] += 7*share;
                if (y+1 < height) {
                    image[3*(index+width)+channel] += 5*share;
                    if (back >= 0 && back < width)
                        image[3*(index+width-direction)+channel] += 3*share;
                    if (forward >= 0 && forward < width)
                        image[3*(index+width+direction)+channel] += share;
                }
            }
        }
    }
}
