"""Render a final-size RGB photograph to the six native OpenPaper 7 pixel colors."""
import argparse
import ctypes
import json
from pathlib import Path

import colour
import numpy as np
from PIL import Image, ImageOps

HERE = Path(__file__).resolve().parent


def linear(rgb):
    rgb = rgb / 255.0
    return np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)


def render(rgb, contrast, chroma):
    profile = json.loads((HERE / "six-colors.json").read_text())
    measured = linear(np.array([entry["srgb"] for entry in profile]))
    native = np.array([list(bytes.fromhex(entry["nativeCode"][1:])) for entry in profile],
                      dtype=np.uint8)
    black, white = measured[:2]
    matrix = colour.RGB_COLOURSPACES["sRGB"].matrix_RGB_to_XYZ
    source = black + linear(rgb) * (white - black)
    lab = colour.XYZ_to_Lab(source @ matrix.T)
    low, high = colour.XYZ_to_Lab(measured[:2] @ matrix.T)[:, 0]
    t = np.clip((lab[:, :, 0] - low) / (high - low), 0, 1)
    lab[:, :, 0] = low + (high-low) * (t ** contrast / (t ** contrast + (1-t) ** contrast))
    neutral = (1-t[:, :, None]) * black + t[:, :, None] * white
    axis = colour.XYZ_to_Lab(neutral @ matrix.T)[:, :, 1:]
    lab[:, :, 1:] = axis + chroma * (lab[:, :, 1:] - axis)
    target = (colour.Lab_to_XYZ(lab) @ np.linalg.inv(matrix).T - black) / (white-black)

    work = np.ascontiguousarray(target, dtype=np.float32)
    palette = np.ascontiguousarray((measured-black) / (white-black), dtype=np.float32)
    indices = np.empty(rgb.shape[:2], dtype=np.uint8)
    function = ctypes.CDLL(str(HERE / "diffuse.so")).diffuse
    function.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_void_p,
                         ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
    function.restype = None
    function(work.ctypes.data, rgb.shape[1], rgb.shape[0], palette.ctypes.data,
             len(palette), 1, indices.ctypes.data)
    indices[np.all(rgb == 0, axis=-1)] = 0
    indices[np.all(rgb == 255, axis=-1)] = 1
    return native[indices]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--contrast", type=float, default=1.25)
    parser.add_argument("--chroma", type=float, default=1.30)
    args = parser.parse_args()
    if args.contrast <= 0 or args.chroma < 0:
        parser.error("Contrast must be positive and chroma nonnegative.")
    with Image.open(args.source) as image:
        rgb = np.asarray(ImageOps.exif_transpose(image).convert("RGB"))
    Image.fromarray(render(rgb, args.contrast, args.chroma)).save(args.output, format="PNG")
