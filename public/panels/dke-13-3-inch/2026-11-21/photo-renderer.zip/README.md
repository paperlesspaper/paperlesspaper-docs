# Render an OpenPaper L color photograph

These profiles were measured on frame-2, a DKE DEPG1330RTE133F5HP with two NT61522 display controllers. The renderer creates uncompressed image-RAM files for the bench firmware’s landscape wiring. It runs offline and does not send data to a device.

## Build and compare

Use a C compiler and Python 3 with NumPy and Pillow. From this directory on macOS or Linux, run

    python3 -m venv .venv
    . .venv/bin/activate
    python3 -m pip install numpy pillow
    cc -O3 -fPIC -shared diffuse.c -o diffuse.so -lm
    python3 render_photo.py photo.jpg six-code-output --mode normal
    python3 render_photo.py photo.jpg sixteen-code-output --mode raw16

The renderer fits the photograph on a white 1600 × 1200 canvas with its EXIF orientation applied. Each drive-cs1.bin and drive-cs2.bin holds 480,000 bytes for one controller. The bench writes these to image RAM (0x10). They contain two four-bit pixel codes per byte, with the first pixel in the high nibble. Both photo profiles use one full refresh at PLL 0x08.

## Profiles in palette.json

- normal uses the six standard codes. seven adds code 0x4.
- raw16 uses all 16 image-RAM codes with serpentine Floyd–Steinberg dithering in linear RGB. Several codes produced nearly identical measured colors.
- raw16-corrected also applies the experimental matrix fitted to the 12 flat patches.
- extended uses 23 candidate two-pass recipes. extended-refit uses the smaller palette obtained by refitting four positions. On this bench each uses a complete preparation at PLL 0x08 followed by a timed drive at PLL 0x07 and a hardware reset 2.8 s after the refresh BUSY signal falls.
- extended-full uses two completed drives at PLL 0x08 and ten measured recipes.

Pass --no-dither to assign each pixel its nearest measured color. Use a separate output directory per run. Two-pass profiles also produce prep-cs1.bin and prep-cs2.bin. The settings.json file records the profile’s PLL and cutoff settings.

Each color entry records the preparation code (when used), drive code and camera-relative linear RGB measured on frame-2. A few values extend beyond the range from zero to one after local black/white normalization. The lookup table maps desired colors to pixel codes. The panel uses its factory voltage waveforms.

Measurements and photographs:
https://docs.paperlesspaper.de/panels/dke-13-3-inch#color-photo-dithering-measurements
