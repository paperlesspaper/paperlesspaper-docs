"""Convert a source image to frame-2 native, per-controller packed 4 bpp RAM images."""
import argparse
import ctypes
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

HERE = Path(__file__).resolve().parent
NATIVE_SIZE = (1600, 1200)

def write_pass(indices, output, name):
    # Match the frame-2 bench wiring and landscape orientation.
    physical = np.rot90(indices)
    for chip, half in enumerate(np.hsplit(physical, 2), start=1):
        packed = (half[:, 0::2] << 4) | half[:, 1::2]
        (output / f'{name}-cs{chip}.bin').write_bytes(packed.tobytes())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--mode', choices=('normal', 'seven', 'raw16', 'raw16-corrected', 'extended', 'extended-refit', 'extended-full'), default='extended')
    parser.add_argument('--no-dither', action='store_true')
    args = parser.parse_args()
    profile = json.loads((HERE/'palette.json').read_text())[args.mode]
    colors = profile['colors']
    # Letterbox the picture on white, with EXIF orientation applied.
    with Image.open(args.source) as image:
        photo = ImageOps.contain(ImageOps.exif_transpose(image).convert('RGB'), NATIVE_SIZE, Image.Resampling.LANCZOS)
    canvas = Image.new('RGB', NATIVE_SIZE, 'white')
    canvas.paste(photo, ((canvas.width-photo.width)//2,(canvas.height-photo.height)//2))
    rgb = np.asarray(canvas, dtype=np.float32)/255
    linear = np.ascontiguousarray(np.where(rgb<=0.04045, rgb/12.92, ((rgb+0.055)/1.055)**2.4))
    if 'linear_rgb_matrix' in profile:
        matrix = np.array(profile['linear_rgb_matrix'])
        proposed = linear @ matrix[:3] + matrix[3]
        fade = np.minimum(1, np.minimum(linear.max(axis=2), 1-linear.min(axis=2)) / .06)
        corrected = np.clip(linear + fade[:,:,None]*np.clip(proposed-linear, -.12, .12), 0, 1)
        # Match the camera trial's eight-bit sRGB preparation before error diffusion.
        corrected_srgb = np.round(255*np.where(corrected <= .0031308, 12.92*corrected,
                                               1.055*corrected**(1/2.4)-.055))/255
        linear = np.ascontiguousarray(np.where(corrected_srgb<=.04045, corrected_srgb/12.92,
                                               ((corrected_srgb+.055)/1.055)**2.4), dtype=np.float32)
    pal = np.ascontiguousarray([e['linear_rgb'] for e in colors],dtype=np.float32)
    height, width = linear.shape[:2]
    indices = np.empty((height,width),dtype=np.uint8)
    library = ctypes.CDLL(str(HERE/'diffuse.so'))
    func = library.diffuse
    func.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_void_p,
                     ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
    func.restype = None
    func(linear.ctypes.data, width, height, pal.ctypes.data, len(colors),
         int(not args.no_dither), indices.ctypes.data)
    args.output.mkdir(exist_ok=True, parents=True)
    stages = ['prep', 'drive'] if profile.get('prep_pll') is not None else ['drive']
    for name in stages:
        write_pass(np.array([e[name] for e in colors], dtype=np.uint8)[indices],args.output,name)
    (args.output/'settings.json').write_text(json.dumps({k:v for k,v in profile.items() if k!='colors'},indent=2)+'\n')

if __name__=='__main__':
    main()
